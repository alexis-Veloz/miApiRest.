//module.exports = {
  //  database: {
    //    host: 'localhost',
      //  user: 'root',
        //password: 'abc1234',
        //database: 'database_links'
   // }
//}

module.exports={
    database:{
        host: 'sql3.freemysqlhosting.net',
        user: 'sql3337781',
        password: 'ktMiG9iGAC',
        database: 'sql3337781'
    }
}